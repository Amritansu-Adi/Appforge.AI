# PROJECT COMPREHENSIVE BLUEPRINT: AppForge AI
> **Revision:** v3.0 — AI Layer Migrated to Python (LangChain + LangGraph + MCP in Python; Frontend + Backend remain JS)
> **Date:** 2025
> **Authors:** Amritansu (Backend Lead + AI Co-builder), Prateeksha Yadav (Frontend Lead + AI Co-builder)

---

## REVISION LOG

| Version | Date | Change | Reason |
|---------|------|--------|--------|
| v1.0 | 2025-Initial | Full blueprint created | Initial consensus achieved |
| v2.0 | 2025-Revised | Task distribution restructured: Amritansu = Backend + AI (LangGraph, MCP, Codegen Chains), Prateeksha = Frontend + AI (PromptTemplates, Output Parsers, Streaming Chains, Docs Chains) | Both contributors need AI hands-on experience; LangChain layer introduced |
| v3.0 | 2025-Revised | AI layer fully migrated to Python (FastAPI + LangChain Python + LangGraph Python + MCP Python). Frontend remains React/JS. Backend remains Node.js/Express. AI layer is now a standalone Python microservice on port 8000. Node.js proxies all `/api/ai/*` and `/api/codegen/*` calls to the Python service. | Requirement change — Python required for all AI/LangChain/LangGraph/MCP code. |

---

## 1. Executive Summary & Core Goals

**What it does:**
AppForge AI is a guided, AI-powered web application that takes a non-technical user from a plain-English app idea through a 5-phase sequential pipeline — idea capture → clarifying questions → diagram generation → full documentation → code generation — and delivers a downloadable, deployable zip of a working React + Node + SQLite application with a step-by-step manual deployment guide.

**Problem Statement:**
Non-technical founders, students, and small business owners cannot bridge the gap between an app idea and a working codebase. Existing AI tools (Copilot, Cursor) require developer-level thinking. AppForge fills the gap upstream — translating human intent into structured technical artefacts before generating code.

**Value Proposition:**
Complete, free, sequential AI pipeline from idea to working zip. No technical vocabulary exposed to users. Fixed output stack ensures reliable code generation. Auth system ensures session persistence and project ownership.

**What's New in v3.0 — Python AI Service:**
The AI layer (LangChain, LangGraph, MCP) is now a **standalone Python microservice** running FastAPI on port 8000. The Node.js Express backend (port 3001) handles auth, session management, database operations, and file downloads — exactly as before. For all AI operations, Node.js acts as a **proxy**: it verifies the JWT, then forwards the request to the Python AI service. The Python service has no auth logic of its own; it trusts requests from Node.js only. The React frontend talks exclusively to the Node.js backend and never directly to the Python service.

**Project Ownership:**
Group Project — Lead Mode. Amritansu is repo owner and backend/AI-infra lead. Prateeksha Yadav is frontend/AI-chains co-lead. Full task distribution defined in Section 5.

**Repository:** https://github.com/prateeksha-yadav/Appforge.AI
**Lead GitHub:** Amritansu-Adi
**Contributor GitHub:** prateeksha-yadav

---

## 2. Technical Stack Mapping

### 2.1 AppForge Platform Stack

| Layer | Technology | Version | Language | Owner | Justification |
|-------|-----------|---------|----------|-------|---------------|
| Frontend Framework | React | 18 | JavaScript | Prateeksha | Component model, ecosystem |
| Build Tool | Vite | 5 | JavaScript | Prateeksha | Fast dev server, standard 2025 tooling |
| Styling | Tailwind CSS | 3 | JavaScript | Prateeksha | Utility-first, responsive |
| Server State | React Query (TanStack) | 5 | JavaScript | Prateeksha | Caching, loading/error states |
| Client/UI State | Zustand | 4 | JavaScript | Prateeksha | Lightweight client state |
| Markdown Render | react-markdown | 9 | JavaScript | Prateeksha | Safe streaming markdown display |
| Diagram Render | Mermaid.js | 10 | JavaScript | Prateeksha | Browser-side, text-to-diagram |
| Backend Runtime | Node.js | 20 LTS | JavaScript | Amritansu | JS consistency |
| Backend Framework | Express | 4 | JavaScript | Amritansu | Minimal REST |
| Database Driver | better-sqlite3 | 9 | JavaScript | Amritansu | Synchronous API, zero server |
| Auth | JWT + bcrypt | — | JavaScript | Amritansu | Stateless tokens |
| **AI Service Runtime** | **Python** | **3.11+** | **Python** | **Both** | **Requirement: AI layer must be Python** |
| **AI Service Framework** | **FastAPI** | **0.111+** | **Python** | **Amritansu** | **Async HTTP server for AI service; SSE support** |
| **AI Orchestration** | **LangChain (Python)** | **0.3.x** | **Python** | **Both** | **Chain composition, prompt templates, output parsers** |
| **AI Pipeline** | **LangGraph (Python)** | **0.2.x** | **Python** | **Amritansu** | **Stateful multi-step AI pipeline as a graph** |
| **MCP Server** | **mcp (Python SDK)** | **latest** | **Python** | **Amritansu** | **Expose validation tools to the LLM as callable tools** |
| **LLM Primary** | **Groq API (llama-3.3-70b)** | — | Python | **Both** | **Fastest free LLM inference** |
| **LLM Fallback** | **Google Gemini Flash 2.0** | — | Python | **Both** | **1M tokens/day free fallback** |
| **LLM Abstraction** | **langchain-groq + langchain-google-genai** | — | Python | **Amritansu** | **Swap models without changing chain logic** |
| **Output Validation** | **Pydantic v2** | **2.x** | **Python** | **Both** | **Replaces Zod for Python; schema validation for parsers + MCP** |
| **Streaming** | **FastAPI StreamingResponse + SSE** | — | Python | **Prateeksha** | **Streams LangChain tokens to Node.js, which relays to browser** |
| Doc Generation | python-docx | — | Python | **Amritansu** | **Markdown → .docx in Python AI service** |
| Zip Generation | zipfile (stdlib) | — | Python | **Amritansu** | **Bundle generated app as .zip in Python service** |
| Code Validation | py_compile + esprima subprocess | — | Python | **Amritansu** | **SQL via sqlite3 stdlib; JS/JSX via node subprocess call** |
| Rate Limiting | express-rate-limit | — | JavaScript | Amritansu | Protect Node.js endpoints |
| **Tracing (Dev)** | **LangSmith** | — | **Python** | **Both** | **Debug chain executions via Python SDK** |
| Deployment | Render (free tier) | — | — | Amritansu | Two services: Node.js web service + Python web service |

### 2.2 Service Breakdown (v3.0)

| Service | Language | Port | Folder | Who Builds It |
|---------|----------|------|--------|---------------|
| React Frontend | JavaScript | 5173 (dev) | `client/` | Prateeksha |
| Node.js Backend | JavaScript | 3001 | `server/` | Amritansu |
| **Python AI Service** | **Python** | **8000** | **`ai-service/`** | **Both** |

> **Integration Rule:** The React frontend ONLY talks to the Node.js backend (`http://localhost:3001`). The Node.js backend calls the Python AI service (`http://localhost:8000`) internally for all AI tasks. The Python AI service is never exposed to the browser.

### 2.3 Generated App Stack (Locked — User Has No Choice)

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite + Tailwind CSS |
| Backend | Node.js 20 + Express 4 |
| Database | SQLite via better-sqlite3 |
| Auth | JWT + bcrypt |
| Env | dotenv + .env |
| Containerisation | Dockerfile + docker-compose (generated, optional) |

### 2.4 Environment Variables

| Variable | Required | Description | Source | Owner |
|----------|----------|-------------|--------|-------|
| GROQ_API_KEY | Yes | Primary LLM inference | console.groq.com | Amritansu |
| GEMINI_API_KEY | Yes | Fallback LLM | aistudio.google.com | Amritansu |
| JWT_SECRET | Yes | AppForge platform auth signing key | `openssl rand -base64 32` | Amritansu |
| AI_SERVICE_URL | Yes | Python AI service base URL | `http://localhost:8000` in dev | Amritansu |
| AI_SERVICE_SECRET | Yes | Shared secret for Node→Python internal auth | `openssl rand -base64 32` | Amritansu |
| LANGSMITH_API_KEY | No (dev only) | LangSmith tracing | smith.langchain.com | Both |
| LANGSMITH_PROJECT | No (dev only) | Project name in LangSmith | e.g. "appforge-dev" | Both |
| NODE_ENV | Yes (prod) | Environment flag | Render dashboard | Amritansu |
| PORT | No | Node.js port. Defaults to 3001 | Auto-set by Render | Amritansu |
| AI_PORT | No | Python service port. Defaults to 8000 | Auto-set by Render | Amritansu |
| DB_PATH | No | Defaults to ./data/appforge.db | Override if needed | Amritansu |

---

## 3. System Architecture & Data Flows

### 3.1 System Architecture Diagram

```mermaid
graph TD
    subgraph CLIENT["Client (React 18 + Vite — :5173) — Prateeksha — JavaScript"]
        UI[Pages & Components]
        RQ[React Query]
        ZS[Zustand Auth Store]
        SSE[EventSource SSE Consumer]
    end

    subgraph SERVER["Node.js Server (Express 4 — :3001) — Amritansu — JavaScript"]
        AUTH[Auth Routes /api/auth]
        SESSION[Session Routes /api/session]
        PROXY[AI Proxy /api/ai/* → forwards to Python]
        DIAG[Diagram Routes /api/diagram]
        DOCS[Docs Routes /api/docs]
        CODEGEN[Codegen Routes /api/codegen]
        DB[(SQLite — appforge.db)]
    end

    subgraph AISERVICE["Python AI Service (FastAPI — :8000) — Python"]
        subgraph PRATEEKSHA_AI["Prateeksha owns — Python"]
            OC[overview_chain.py]
            QC[questions_chain.py]
            DC[documentation_chain.py]
            PT[prompt templates .py]
            OP[output parsers / Pydantic]
        end
        subgraph AMRITANSU_AI["Amritansu owns — Python"]
            LG[appforge_graph.py — LangGraph StateGraph]
            DIAGC[diagram_chain.py + Self-Correction]
            CGC[codegen_chain.py — 6 sub-steps]
            MCPS[MCP Server — validation tools in Python]
        end
        LM[LangChain ChatModel — Groq primary / Gemini fallback]
        FASTAPI[FastAPI Router — exposes AI endpoints internally]
    end

    subgraph EXTERNAL["External"]
        GROQ[Groq API]
        GEMINI[Gemini Flash API]
        LS[LangSmith Tracing]
    end

    UI --> RQ --> PROXY
    UI --> ZS
    UI --> SSE
    SSE -->|SSE stream via Node.js| PROXY

    PROXY -->|internal HTTP| FASTAPI
    FASTAPI --> OC & QC & DIAGC & DC & CODEGEN

    OC --> PT --> LM
    QC --> PT --> LM
    DC --> PT --> LM
    DIAGC --> PT --> LM
    CGC --> PT --> LM

    OC --> OP
    QC --> OP
    DIAGC --> OP
    CGC --> OP

    LG --> OC & QC & DIAGC & DC & CGC

    LM -->|primary| GROQ
    LM -->|fallback on 429| GEMINI
    LM -.->|traces| LS

    AUTH --> DB
    SESSION --> DB
    PROXY --> DB
    DIAG --> DB
    DOCS --> DB
    CODEGEN --> DB
```

### 3.2 AI Layer Internal Architecture (Python)

```mermaid
graph LR
    subgraph LANGCHAIN["LangChain Python Building Blocks"]
        CPT[ChatPromptTemplate.from_messages]
        PYD[PydanticOutputParser]
        JOP[JsonOutputParser]
        STROP[StrOutputParser]
        LCEL[LCEL Pipe — prompt | model | parser]
        RB[with_fallbacks]
        CB[StreamingCallbackHandler]
    end

    subgraph LANGGRAPH["LangGraph Python — AppForgeGraph"]
        S0[START]
        N1[overview_node]
        N2[questions_node]
        N3[diagrams_node]
        N4[docs_node]
        N5[codegen_node]
        S6[END]
        CHK[SqliteSaver — checkpoint to DB]

        S0 --> N1 --> N2 --> N3 --> N4 --> N5 --> S6
        CHK -.->|persists| N1 & N2 & N3 & N4 & N5
    end

    subgraph MCP["MCP Server Python — AppForge Tools"]
        T1[validate_mermaid tool]
        T2[validate_js_syntax tool]
        T3[validate_sql_schema tool]
        T4[validate_jsx_syntax tool]
    end

    subgraph MODELS["LLM Models — Amritansu wraps in Python"]
        GM[ChatGroq]
        GEM[ChatGoogleGenerativeAI]
        FB[with_fallbacks — Groq → Gemini]
    end

    N1 -->|uses| CPT & PYD
    N2 -->|uses| CPT & JOP
    N3 -->|uses| CPT & JOP & T1
    N4 -->|uses| CPT & STROP & CB
    N5 -->|uses| CPT & JOP & T2 & T3 & T4

    CPT --> FB
    FB --> GM
    FB -->|429 fallback| GEM
```

### 3.3 Request Flow — How Node.js Proxies to Python

```mermaid
sequenceDiagram
    participant Browser
    participant NodeJS as Node.js :3001
    participant Python as Python AI :8000
    participant Groq

    Browser->>NodeJS: POST /api/ai/overview (Bearer JWT)
    NodeJS->>NodeJS: Verify JWT → extract userId, sessionId
    NodeJS->>NodeJS: Load session from SQLite
    NodeJS->>Python: POST /internal/ai/overview (X-Internal-Secret header + payload)
    Python->>Python: Run LangGraph overview_node → overviewChain
    Python->>Groq: LLM call
    Groq-->>Python: LLM response
    Python->>Python: Parse → Pydantic model
    Python-->>NodeJS: 200 JSON overview object
    NodeJS->>NodeJS: Save overview_json to SQLite sessions table
    NodeJS-->>Browser: 200 JSON overview object
```

For **streaming** responses (docs, codegen), Node.js opens an SSE connection to the browser and simultaneously opens an HTTP streaming connection to the Python service, piping Python's chunks directly to the browser's SSE stream.

### 3.4 Data Flow Diagram (Full Pipeline)

```mermaid
flowchart TD
    A([User registers / logs in]) --> B[POST /api/auth/register or /login — Node.js]
    B --> C[JWT issued → stored in Zustand + localStorage]
    C --> D[POST /api/session/create → sessionId in SQLite — Node.js]
    D --> E[User submits idea text]

    E --> F["POST /api/ai/overview — Node.js proxy
    → Python AI: overview_node → OverviewChain
    → ChatPromptTemplate | ChatGroq | PydanticOutputParser
    → Pydantic model → Node.js saves to sessions.overview_json"]

    F --> G[User reviews Overview card and confirms]
    G --> H["POST /api/ai/questions — Node.js proxy
    → Python AI: questions_node → QuestionsChain
    → ChatPromptTemplate | ChatGroq | JsonOutputParser
    → question list → Node.js saves to questions table"]

    H --> I[User answers questions one by one]
    I --> J[POST /api/answers/save per answer — Node.js → SQLite]

    J --> K["POST /api/ai/diagrams — Node.js proxy
    → Python AI: diagrams_node → DiagramChain
    → ChatPromptTemplate | ChatGroq | JsonOutputParser
    → 3 Mermaid strings
    → MCP Tool: validate_mermaid x3 (Python)
    → Self-correct loop ≤2 if invalid
    → Node.js saves to diagrams table"]

    K --> L{All 3 diagrams approved by user?}
    L -->|No — Regenerate| K
    L -->|Yes| M["POST /api/ai/srs → docs_node → DocumentationChain SSE stream → python-docx
    POST /api/ai/sdd → same pattern
    POST /api/ai/brief → streaming markdown only"]

    M --> N[User downloads SRS + SDD .docx, reads Brief live]
    N --> O["POST /api/codegen/start — Node.js proxy → SSE
    → Python AI: codegen_node → CodegenChain — 6 sub-steps
    → Each sub-step: ChatPromptTemplate | ChatGroq | StrOutputParser
    → MCP Tool: validate_sql / validate_js / validate_jsx (Python)
    → Self-correct ≤2 on failure
    → Files saved → zip assembled by Python service
    → Node.js relays SSE progress to browser"]

    O --> P[GET /api/codegen/download/:sessionId → Node.js serves zip file]
    P --> Q[DEPLOYMENT.md shown inline — user deploys]
```

### 3.5 LangGraph State Schema (Python)

```python
# ai-service/graph/appforge_state.py
from typing import TypedDict, Optional, Literal
from dataclasses import dataclass, field

class OverviewOutput(TypedDict):
    app_name: str
    one_liner: str
    target_users: list[str]
    core_features: list[str]
    complexity: Literal["simple", "standard", "complex"]
    tech_notes: str
    data_entities: list[str]

class Question(TypedDict):
    question_id: str
    category: str
    question: str
    type: Literal["text", "choice"]
    options: Optional[list[str]]

class Answer(TypedDict):
    question_id: str
    answer_text: str

class DiagramSet(TypedDict):
    use_case_diagram: str
    architecture_diagram: str
    er_diagram: str

class GeneratedFile(TypedDict):
    path: str
    content: str
    source: Literal["ai", "template"]

class AppForgeState(TypedDict):
    # Session metadata
    session_id: str
    user_id: str
    current_phase: Literal["overview", "questions", "diagrams", "docs", "codegen", "complete"]

    # Phase 1 — Overview
    idea_text: str
    overview_json: Optional[OverviewOutput]

    # Phase 2 — Questions
    questions: list[Question]
    answers: list[Answer]
    complexity: Optional[Literal["simple", "standard", "complex"]]

    # Phase 3 — Diagrams
    diagrams: Optional[DiagramSet]
    diagram_errors: list[str]

    # Phase 4 — Docs
    srs_markdown: str
    sdd_markdown: str
    brief_markdown: str

    # Phase 5 — Codegen
    generated_files: list[GeneratedFile]
    zip_path: Optional[str]

    # Retry tracking
    retry_count: int
    last_error: Optional[str]
```

### 3.6 Authentication State Machine

```mermaid
stateDiagram-v2
    [*] --> Unauthenticated
    Unauthenticated --> Registering : POST /api/auth/register
    Registering --> Authenticated : 200 + JWT
    Registering --> Unauthenticated : 400 validation error
    Unauthenticated --> LoggingIn : POST /api/auth/login
    LoggingIn --> Authenticated : 200 + JWT
    LoggingIn --> Unauthenticated : 401 wrong credentials
    Authenticated --> SessionActive : POST /api/session/create
    SessionActive --> Phase1 : idea submitted
    Phase1 --> Phase2 : overview confirmed
    Phase2 --> Phase3 : all questions answered
    Phase3 --> Phase4 : all 3 diagrams approved
    Phase4 --> Phase5 : docs downloaded/confirmed
    Phase5 --> Complete : zip downloaded
    Complete --> SessionActive : start new project
    Authenticated --> Unauthenticated : JWT expired or logout
```

### 3.7 Session Phase Flow (Frontend Routing)

```mermaid
stateDiagram-v2
    [*] --> Landing : /
    Landing --> IdeaPage : click Start Building (auth required)
    IdeaPage --> OverviewPage : POST overview success
    OverviewPage --> IdeaPage : user clicks Rephrase
    OverviewPage --> QuestionsPage : user confirms
    QuestionsPage --> DiagramsPage : all answers saved
    DiagramsPage --> DocsPage : all 3 approved
    DocsPage --> CodePage : user confirms docs
    CodePage --> CompletePage : zip ready
    CompletePage --> IdeaPage : start new project
    Landing --> HistoryPage : /history (auth required)
    HistoryPage --> IdeaPage : resume session
```

---

## 4. Database Schema & Data Models

> **Note:** All database operations remain in Node.js using `better-sqlite3`. The Python AI service does NOT access SQLite directly. The Python service returns AI results to Node.js, and Node.js handles all DB writes. The one exception is the `langgraph_checkpoints` table, which LangGraph's `SqliteSaver` writes to — Amritansu configures this to point to the same SQLite file via a Python database connection.

### 4.1 Table: `users`
| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | TEXT | PRIMARY KEY | UUID v4 |
| email | TEXT | NOT NULL, UNIQUE | Lowercased on insert |
| password_hash | TEXT | NOT NULL | bcrypt, 10 rounds |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | |
| last_login | DATETIME | nullable | Updated on each login |

### 4.2 Table: `sessions`
| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | TEXT | PRIMARY KEY | UUID v4 |
| user_id | TEXT | NOT NULL, FK → users(id) ON DELETE CASCADE | |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | |
| updated_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | |
| status | TEXT | NOT NULL DEFAULT 'idea' | idea\|overview\|questions\|diagrams\|docs\|codegen\|complete |
| idea_text | TEXT | nullable | Raw user input |
| overview_json | TEXT | nullable | JSON string of Step 1 output |
| complexity | TEXT | nullable | simple\|standard\|complex |
| app_name | TEXT | nullable | Extracted by Step 1 AI |

### 4.3 Table: `questions`
| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INTEGER | PRIMARY KEY AUTOINCREMENT | |
| session_id | TEXT | NOT NULL, FK → sessions(id) ON DELETE CASCADE | |
| question_id | TEXT | NOT NULL | e.g. "q1", "q2" |
| category | TEXT | nullable | Users & Roles, Core Data, etc. |
| question | TEXT | NOT NULL | Display text |
| type | TEXT | NOT NULL | text\|choice |
| options_json | TEXT | nullable | JSON array of option strings or null |

### 4.4 Table: `answers`
| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INTEGER | PRIMARY KEY AUTOINCREMENT | |
| session_id | TEXT | NOT NULL, FK → sessions(id) ON DELETE CASCADE | |
| question_id | TEXT | NOT NULL | Matches questions.question_id |
| answer_text | TEXT | NOT NULL | Min 5 chars enforced at API level |
| answered_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | |

### 4.5 Table: `diagrams`
| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INTEGER | PRIMARY KEY AUTOINCREMENT | |
| session_id | TEXT | NOT NULL, FK → sessions(id) ON DELETE CASCADE | |
| diagram_type | TEXT | NOT NULL | usecase\|architecture\|er |
| mermaid_src | TEXT | NOT NULL | Raw Mermaid.js string |
| approved | INTEGER | NOT NULL DEFAULT 0 | 0 or 1 |
| version | INTEGER | NOT NULL DEFAULT 1 | Increments on regenerate |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | |

### 4.6 Table: `documents`
| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INTEGER | PRIMARY KEY AUTOINCREMENT | |
| session_id | TEXT | NOT NULL, FK → sessions(id) ON DELETE CASCADE | |
| doc_type | TEXT | NOT NULL | srs\|sdd\|brief |
| file_path | TEXT | nullable | Absolute server path to .docx file (generated by Python, stored on Python service volume) |
| markdown_text | TEXT | nullable | Raw Markdown from AI |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | |

### 4.7 Table: `generated_files`
| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | INTEGER | PRIMARY KEY AUTOINCREMENT | |
| session_id | TEXT | NOT NULL, FK → sessions(id) ON DELETE CASCADE | |
| file_path | TEXT | NOT NULL | Relative path within generated app |
| content | TEXT | NOT NULL | Full file content as string |
| status | TEXT | NOT NULL DEFAULT 'pending' | pending\|generating\|validated\|packaged\|failed |
| source | TEXT | NOT NULL | ai\|template |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | |

### 4.8 Table: `langgraph_checkpoints`
| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| thread_id | TEXT | NOT NULL | Maps to sessionId |
| checkpoint_id | TEXT | NOT NULL | LangGraph internal ID |
| parent_checkpoint_id | TEXT | nullable | For branching |
| type | TEXT | NOT NULL | State type identifier |
| checkpoint | TEXT | NOT NULL | JSON blob of full state |
| metadata | TEXT | NOT NULL | JSON metadata |

**Primary Key:** `(thread_id, checkpoint_id)`
**Note:** Managed by LangGraph's Python `SqliteSaver`. Connects to the same `appforge.db` file. Do not write to it manually.

---

## 5. AI Layer — Detailed Breakdown (Python)

> **This section is the heart of v3.0. All AI code is Python. Both contributors must read it fully before writing any AI code.**

### 5.1 Philosophy

The AI layer is a **standalone Python service** (`ai-service/`) running **FastAPI**. It exposes internal HTTP endpoints consumed only by the Node.js backend. Every AI interaction is a **LangChain (Python) chain** composed using LCEL (LangChain Expression Language) pipe syntax: `prompt | model | parser`. Chains are wired together into a **LangGraph StateGraph** (Python). An **MCP server** (Python SDK) exposes validation tools. The Python service never handles auth — it trusts an internal shared secret header set by Node.js.

**Why FastAPI?** It supports async natively, has first-class SSE streaming support via `StreamingResponse`, and pairs naturally with async LangChain chains. Uvicorn is used as the ASGI server.

### 5.2 Folder Structure — Python AI Service

```
ai-service/
├── main.py                         ← Amritansu: FastAPI app + router registration + startup
├── requirements.txt                ← Amritansu: all Python dependencies
├── .env                            ← Amritansu: GROQ_API_KEY, GEMINI_API_KEY, etc.
├── models/
│   └── llm.py                      ← Amritansu: ChatGroq + ChatGemini with .with_fallbacks()
├── prompts/
│   ├── overview_prompt.py          ← Prateeksha: ChatPromptTemplate for Step 1
│   ├── questions_prompt.py         ← Prateeksha: ChatPromptTemplate for Step 2
│   ├── diagrams_prompt.py          ← Prateeksha: ChatPromptTemplate for Step 3 (Mermaid)
│   ├── srs_prompt.py               ← Prateeksha: ChatPromptTemplate for SRS doc
│   ├── sdd_prompt.py               ← Prateeksha: ChatPromptTemplate for SDD doc
│   ├── brief_prompt.py             ← Prateeksha: ChatPromptTemplate for Brief
│   └── codegen_prompts.py          ← Prateeksha: 6 sub-step ChatPromptTemplates
├── parsers/
│   ├── overview_parser.py          ← Prateeksha: PydanticOutputParser for overview JSON
│   ├── questions_parser.py         ← Prateeksha: JsonOutputParser for question array
│   ├── diagrams_parser.py          ← Amritansu: JsonOutputParser for diagram object
│   └── codegen_parser.py           ← Amritansu: StrOutputParser per codegen sub-step
├── chains/
│   ├── overview_chain.py           ← Prateeksha: LCEL pipe — prompt | model | parser
│   ├── questions_chain.py          ← Prateeksha: LCEL pipe — prompt | model | parser
│   ├── diagram_chain.py            ← Amritansu: LCEL pipe + MCP validation loop
│   ├── documentation_chain.py      ← Prateeksha: Async streaming chain (astream)
│   └── codegen_chain.py            ← Amritansu: 6-step orchestrator with MCP tool calls
├── graph/
│   ├── appforge_graph.py           ← Amritansu: LangGraph StateGraph definition
│   ├── appforge_state.py           ← Amritansu: TypedDict state schema (Section 3.5)
│   └── nodes/
│       ├── overview_node.py        ← Amritansu: node wrapper calling overview_chain
│       ├── questions_node.py       ← Amritansu: node wrapper calling questions_chain
│       ├── diagrams_node.py        ← Amritansu: node wrapper calling diagram_chain
│       ├── docs_node.py            ← Amritansu: node wrapper calling documentation_chain
│       └── codegen_node.py         ← Amritansu: node wrapper calling codegen_chain
├── mcp/
│   ├── server.py                   ← Amritansu: FastMCP server with all validation tools
│   ├── tools/
│   │   ├── validate_mermaid.py     ← Amritansu
│   │   ├── validate_js.py          ← Amritansu (uses node subprocess)
│   │   ├── validate_jsx.py         ← Amritansu (uses node subprocess)
│   │   └── validate_sql.py         ← Amritansu (uses sqlite3 stdlib)
│   └── mcp_client.py               ← Amritansu: in-process client calling tool functions
├── routers/
│   ├── ai_router.py                ← Amritansu: FastAPI routes for /internal/ai/*
│   ├── codegen_router.py           ← Amritansu: FastAPI routes for /internal/codegen/*
│   └── docs_router.py              ← Amritansu: FastAPI SSE routes for /internal/docs/*
├── services/
│   ├── doc_generator.py            ← Amritansu: markdown → .docx using python-docx
│   └── zip_builder.py              ← Amritansu: assembles generated app .zip
└── tests/
    ├── test_overview_chain.py      ← Prateeksha
    ├── test_questions_chain.py     ← Prateeksha
    ├── test_diagram_chain.py       ← Amritansu
    ├── test_codegen_chain.py       ← Amritansu
    └── test_mcp_tools.py           ← Amritansu
```

### 5.3 Python requirements.txt

```
fastapi>=0.111.0
uvicorn[standard]>=0.29.0
langchain>=0.3.0
langchain-core>=0.3.0
langchain-groq>=0.2.0
langchain-google-genai>=2.0.0
langgraph>=0.2.0
langgraph-checkpoint-sqlite>=2.0.0
langsmith>=0.1.0
pydantic>=2.7.0
python-docx>=1.1.0
mcp>=1.0.0
httpx>=0.27.0
python-dotenv>=1.0.0
```

---

### 5.4 Prateeksha's AI Responsibilities — Python Chains 1, 2, 4

#### AI Task P-1: LangChain Model Abstraction (consume, not build)
Prateeksha imports the `llm` object from `ai-service/models/llm.py` (built by Amritansu). She treats it as a drop-in ChatModel and never configures fallbacks herself.

#### AI Task P-2: Overview Chain (`overview_chain.py`)

**Key Python LangChain concepts Prateeksha will learn:** `ChatPromptTemplate.from_messages()`, `PydanticOutputParser`, LCEL pipe syntax (`prompt | model | parser`), Pydantic v2 model for structured output.

```python
# ai-service/chains/overview_chain.py — Prateeksha's file
from langchain_core.runnables import RunnableSequence
from ai_service.models.llm import llm
from ai_service.prompts.overview_prompt import overview_prompt
from ai_service.parsers.overview_parser import overview_parser

# LCEL pipe — this is the Python equivalent of RunnableSequence.from([])
overview_chain = overview_prompt | llm | overview_parser

# Usage:
# result = await overview_chain.ainvoke({
#     "idea_text": "...",
#     "format_instructions": overview_parser.get_format_instructions()
# })
```

**Overview Parser (Pydantic v2 — replaces Zod):**

```python
# ai-service/parsers/overview_parser.py — Prateeksha's file
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field
from typing import Literal

class OverviewOutput(BaseModel):
    app_name: str = Field(description="Short memorable name for the app")
    one_liner: str = Field(description="One sentence description of the app")
    target_users: list[str] = Field(description="List of user types")
    core_features: list[str] = Field(min_length=3, max_length=8, description="Main features")
    complexity: Literal["simple", "standard", "complex"]
    tech_notes: str = Field(description="Any implicit technical requirements")
    data_entities: list[str] = Field(description="Key data objects the app will manage")

overview_parser = PydanticOutputParser(pydantic_object=OverviewOutput)
```

**Overview Prompt:**

```python
# ai-service/prompts/overview_prompt.py — Prateeksha's file
from langchain_core.prompts import ChatPromptTemplate

overview_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are AppForge AI, a technical architect that analyses app ideas.
Given a plain-English app idea, extract structured information about the app.

{format_instructions}

Respond ONLY with a valid JSON object. No markdown fences. No preamble."""),
    ("human", "App idea: {idea_text}"),
])
```

#### AI Task P-3: Questions Chain (`questions_chain.py`)

**Key Python LangChain concepts:** `JsonOutputParser`, passing structured data into prompts, question count by complexity.

```python
# ai-service/chains/questions_chain.py — Prateeksha's file
from langchain_core.output_parsers import JsonOutputParser
from ai_service.models.llm import llm
from ai_service.prompts.questions_prompt import questions_prompt

questions_chain = questions_prompt | llm | JsonOutputParser()

# Input:  { "overview_json": str, "question_count": int }
# Output: list[{ question_id, category, question, type, options? }]
```

**Prateeksha writes `questions_prompt.py`** — the system message must include the exact JSON schema of a question object, the exact count to generate from `{question_count}`, and "respond only with a raw JSON array, no markdown fences".

#### AI Task P-4: Documentation Chains (`documentation_chain.py`)

**Key Python LangChain concepts:** `astream()` for async token streaming, `StrOutputParser`, async generator pattern for SSE.

```python
# ai-service/chains/documentation_chain.py — Prateeksha's file
from langchain_core.output_parsers import StrOutputParser
from ai_service.models.llm import llm
from ai_service.prompts.srs_prompt import srs_prompt
from ai_service.prompts.sdd_prompt import sdd_prompt
from ai_service.prompts.brief_prompt import brief_prompt
from typing import AsyncGenerator, Callable, Literal

PROMPT_MAP = {
    "srs": srs_prompt,
    "sdd": sdd_prompt,
    "brief": brief_prompt,
}

async def stream_doc(
    doc_type: Literal["srs", "sdd", "brief"],
    session_context: dict,
    on_token: Callable[[str], None],
    on_complete: Callable[[str], None],
) -> None:
    """
    Streams document tokens from the LLM.
    on_token is called for each chunk (used by FastAPI to send SSE events).
    on_complete is called once with the full accumulated text.
    """
    prompt = PROMPT_MAP[doc_type]
    chain = prompt | llm | StrOutputParser()

    accumulated = ""
    async for chunk in chain.astream(session_context):
        accumulated += chunk
        on_token(chunk)         # caller sends: data: <chunk>\n\n  over SSE

    on_complete(accumulated)    # caller saves to DB + triggers .docx if needed
```

**Prateeksha writes all three prompt files** (`srs_prompt.py`, `sdd_prompt.py`, `brief_prompt.py`) as `ChatPromptTemplate.from_messages()` objects. These are large, detailed system prompts defining each document's structure. Writing them is real prompt engineering work.

**FastAPI SSE endpoint in `docs_router.py` (Amritansu wires this):**

```python
# ai-service/routers/docs_router.py — Amritansu wires; Prateeksha's chain is called here
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from ai_service.chains.documentation_chain import stream_doc

router = APIRouter(prefix="/internal/docs")

@router.post("/stream/{doc_type}")
async def stream_document(doc_type: str, payload: dict):
    async def event_generator():
        def on_token(chunk: str):
            pass  # captured via async queue below

    # Use an async generator that yields SSE-formatted chunks
    async def generate():
        full_text = ""
        prompt_map_context = payload.get("session_context", {})

        async def _on_token(chunk: str):
            nonlocal full_text
            full_text += chunk
            yield f"data: {chunk}\n\n"

        chain = PROMPT_MAP[doc_type] | llm | StrOutputParser()
        async for chunk in chain.astream(prompt_map_context):
            full_text += chunk
            yield f"data: {chunk}\n\n"

        yield "data: DONE\n\n"

    return StreamingResponse(generate(), media_type="text/event-stream")
```

**What Prateeksha learns from AI tasks P-2, P-3, P-4:**
- LCEL pipe syntax (`prompt | model | parser`) — Python's elegant chain composition
- Pydantic v2 models as structured output schemas (Python's answer to Zod)
- How to write effective system prompts that reliably produce structured JSON
- How LangChain async streaming works in Python (`astream()`)
- `JsonOutputParser` for list-structured LLM output
- How FastAPI SSE + LangChain streaming connect end-to-end

---

### 5.5 Amritansu's AI Responsibilities — Model Abstraction, Graph, Diagram Chain, Codegen Chain, MCP Server

#### AI Task A-1: LLM Model Abstraction (`llm.py`)

```python
# ai-service/models/llm.py — Amritansu's file
from langchain_groq import ChatGroq
from langchain_google_genai import ChatGoogleGenerativeAI
import os

groq = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0.3,
    api_key=os.environ["GROQ_API_KEY"],
)

gemini = ChatGoogleGenerativeAI(
    model="gemini-2.0-flash",
    temperature=0.3,
    google_api_key=os.environ["GEMINI_API_KEY"],
)

# Automatically falls back to Gemini if Groq returns 429 or 5xx
llm = groq.with_fallbacks([gemini])
```

#### AI Task A-2: LangGraph StateGraph (`appforge_graph.py`)

```python
# ai-service/graph/appforge_graph.py — Amritansu's file
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver
from ai_service.graph.appforge_state import AppForgeState
from ai_service.graph.nodes.overview_node import overview_node
from ai_service.graph.nodes.questions_node import questions_node
from ai_service.graph.nodes.diagrams_node import diagrams_node
from ai_service.graph.nodes.docs_node import docs_node
from ai_service.graph.nodes.codegen_node import codegen_node
import sqlite3

# Reuse same DB file as Node.js (path from env)
conn = sqlite3.connect(os.environ.get("DB_PATH", "./data/appforge.db"), check_same_thread=False)
checkpointer = SqliteSaver(conn)

builder = StateGraph(AppForgeState)
builder.add_node("overview",  overview_node)
builder.add_node("questions", questions_node)
builder.add_node("diagrams",  diagrams_node)
builder.add_node("docs",      docs_node)
builder.add_node("codegen",   codegen_node)

builder.add_edge(START,       "overview")
builder.add_edge("overview",  "questions")
builder.add_edge("questions", "diagrams")
builder.add_edge("diagrams",  "docs")
builder.add_edge("docs",      "codegen")
builder.add_edge("codegen",   END)

compiled_graph = builder.compile(checkpointer=checkpointer)
```

**Node pattern (Amritansu writes all 5 nodes):**

```python
# ai-service/graph/nodes/overview_node.py — Amritansu's file
from ai_service.chains.overview_chain import overview_chain
from ai_service.parsers.overview_parser import overview_parser

async def overview_node(state: dict) -> dict:
    result = await overview_chain.ainvoke({
        "idea_text": state["idea_text"],
        "format_instructions": overview_parser.get_format_instructions(),
    })
    # result is a Pydantic OverviewOutput model instance
    return {
        "overview_json": result.model_dump(),
        "current_phase": "questions",
    }
    # Returning partial dict — LangGraph merges into AppForgeState automatically
```

**Important:** The graph is NOT run end-to-end automatically. Each phase is triggered by the corresponding FastAPI endpoint. Amritansu calls `await compiled_graph.ainvoke(partial_state, config={"configurable": {"thread_id": session_id}})` at each phase boundary. Because of `SqliteSaver` checkpointing, the graph resumes from exactly where it left off.

#### AI Task A-3: Diagram Chain (`diagram_chain.py`)

```python
# ai-service/chains/diagram_chain.py — Amritansu's file
from langchain_core.output_parsers import JsonOutputParser
from ai_service.models.llm import llm
from ai_service.prompts.diagrams_prompt import diagrams_prompt
from ai_service.mcp.mcp_client import mcp_client
import json

MAX_RETRIES = 2

async def generate_diagrams(overview_json: dict, answers: list) -> dict:
    """
    Generates 3 Mermaid diagrams with MCP-powered self-correction.
    Returns: { use_case_diagram, architecture_diagram, er_diagram }
    """
    chain = diagrams_prompt | llm | JsonOutputParser()
    last_error = None

    for attempt in range(MAX_RETRIES + 1):
        raw = await chain.ainvoke({
            "overview_json": json.dumps(overview_json),
            "answers": json.dumps(answers),
            "previous_error": f"Previous attempt failed: {last_error}. Fix the Mermaid syntax." if last_error else "",
        })

        # Call MCP tool to validate each diagram
        results = await asyncio.gather(
            mcp_client.call_tool("validate_mermaid", {"src": raw["use_case_diagram"], "type": "usecase"}),
            mcp_client.call_tool("validate_mermaid", {"src": raw["architecture_diagram"], "type": "architecture"}),
            mcp_client.call_tool("validate_mermaid", {"src": raw["er_diagram"], "type": "er"}),
        )

        errors = [r["error"] for r in results if not r["valid"]]
        if not errors:
            return raw  # All valid

        last_error = "; ".join(errors)

    raise ValueError(f"Diagram generation failed after {MAX_RETRIES} retries: {last_error}")
```

#### AI Task A-4: MCP Server (`server.py`)

**Python MCP using `FastMCP` — the high-level Python MCP interface:**

```python
# ai-service/mcp/server.py — Amritansu's file
from mcp.server.fastmcp import FastMCP
import subprocess, sqlite3, json, tempfile, os

mcp = FastMCP("appforge-validator")

@mcp.tool()
def validate_mermaid(src: str, type: str) -> dict:
    """Validate Mermaid diagram syntax using Node.js subprocess."""
    # Mermaid has no Python parser; we use a small node script
    script = f"""
const mermaid = require('mermaid');
mermaid.parse(`{src.replace('`', '\\`')}`).then(() => {{
    process.stdout.write(JSON.stringify({{valid: true}}));
}}).catch(err => {{
    process.stdout.write(JSON.stringify({{valid: false, error: err.message}}));
}});
"""
    try:
        result = subprocess.run(
            ["node", "-e", script],
            capture_output=True, text=True, timeout=10
        )
        return json.loads(result.stdout)
    except Exception as e:
        return {"valid": False, "error": str(e)}


@mcp.tool()
def validate_js_syntax(code: str, filename: str) -> dict:
    """Validate JavaScript syntax using Node.js acorn via subprocess."""
    script = f"""
const acorn = require('acorn');
try {{
    acorn.parse({json.dumps(code)}, {{ecmaVersion: 2022, sourceType: 'module'}});
    process.stdout.write(JSON.stringify({{valid: true}}));
}} catch(err) {{
    process.stdout.write(JSON.stringify({{valid: false, error: err.message, line: err.loc?.line}}));
}}
"""
    try:
        result = subprocess.run(["node", "-e", script], capture_output=True, text=True, timeout=10)
        return json.loads(result.stdout)
    except Exception as e:
        return {"valid": False, "error": str(e)}


@mcp.tool()
def validate_jsx_syntax(code: str, filename: str) -> dict:
    """Validate JSX syntax using Node.js @babel/parser via subprocess."""
    script = f"""
const parser = require('@babel/parser');
try {{
    parser.parse({json.dumps(code)}, {{sourceType: 'module', plugins: ['jsx']}});
    process.stdout.write(JSON.stringify({{valid: true}}));
}} catch(err) {{
    process.stdout.write(JSON.stringify({{valid: false, error: err.message, line: err.loc?.line}}));
}}
"""
    try:
        result = subprocess.run(["node", "-e", script], capture_output=True, text=True, timeout=10)
        return json.loads(result.stdout)
    except Exception as e:
        return {"valid": False, "error": str(e)}


@mcp.tool()
def validate_sql_schema(sql: str) -> dict:
    """Validate SQL schema by running against an in-memory SQLite DB (Python stdlib)."""
    try:
        conn = sqlite3.connect(":memory:")
        conn.executescript(sql)
        conn.close()
        return {"valid": True}
    except sqlite3.Error as e:
        return {"valid": False, "error": str(e)}
```

> **Note on JS/JSX validation from Python:** The `validate_mermaid`, `validate_js_syntax`, and `validate_jsx_syntax` tools call Node.js via `subprocess`. This requires that the Python AI service's container/environment has `node`, `acorn`, and `@babel/parser` installed globally. Amritansu must add a `setup.sh` or Dockerfile step to install these. The `validate_sql_schema` tool uses Python's built-in `sqlite3` — no subprocess needed.

**`mcp_client.py` — In-process client:**

```python
# ai-service/mcp/mcp_client.py — Amritansu's file
# Calls MCP tool handler functions directly in-process (no HTTP overhead).
from ai_service.mcp.tools.validate_mermaid import validate_mermaid
from ai_service.mcp.tools.validate_js import validate_js_syntax
from ai_service.mcp.tools.validate_jsx import validate_jsx_syntax
from ai_service.mcp.tools.validate_sql import validate_sql_schema

TOOL_MAP = {
    "validate_mermaid":    validate_mermaid,
    "validate_js_syntax":  validate_js_syntax,
    "validate_jsx_syntax": validate_jsx_syntax,
    "validate_sql_schema": validate_sql_schema,
}

class McpClient:
    async def call_tool(self, name: str, args: dict) -> dict:
        handler = TOOL_MAP.get(name)
        if not handler:
            raise ValueError(f"Unknown MCP tool: {name}")
        # All tool handlers are sync; run in thread pool to avoid blocking async loop
        import asyncio
        return await asyncio.get_event_loop().run_in_executor(None, lambda: handler(**args))

mcp_client = McpClient()
```

#### AI Task A-5: Codegen Chain (`codegen_chain.py`)

```python
# ai-service/chains/codegen_chain.py — Amritansu's file
from langchain_core.output_parsers import StrOutputParser
from ai_service.models.llm import llm
from ai_service.mcp.mcp_client import mcp_client
from ai_service.prompts import codegen_prompts
from typing import Callable, AsyncGenerator
import asyncio

MAX_RETRIES = 2

async def generate_and_validate(
    prompt,
    input_data: dict,
    validator_tool: str,
    filename: str,
    emit: Callable[[dict], None],
) -> str | None:
    chain = prompt | llm | StrOutputParser()
    last_error = None

    for attempt in range(MAX_RETRIES + 1):
        emit({"step": filename, "status": "generating", "message": f"Generating {filename}..."})
        code = await chain.ainvoke({**input_data, "previous_error": last_error or ""})

        emit({"step": filename, "status": "validating", "message": f"Validating {filename}..."})
        validation = await mcp_client.call_tool(validator_tool, {"code": code, "filename": filename})

        if validation["valid"]:
            emit({"step": filename, "status": "validated", "message": f"{filename} ready ✓"})
            return code

        last_error = f"Line {validation.get('line', '?')}: {validation['error']}"
        emit({"step": filename, "status": "retrying", "message": f"Fixing {filename}: {last_error}"})

    emit({"step": filename, "status": "failed", "message": f"{filename} failed after {MAX_RETRIES} retries"})
    return None  # include in zip as best-effort


async def run_codegen_chain(state: dict, emit: Callable[[dict], None]) -> list[dict]:
    overview_json = state["overview_json"]
    sdd_markdown = state["sdd_markdown"]
    files = []

    # Step 5a: SQL Schema
    schema_sql = await generate_and_validate(
        prompt=codegen_prompts.schema_prompt,
        input_data={"sdd_markdown": sdd_markdown, "overview_json": str(overview_json)},
        validator_tool="validate_sql_schema",
        filename="schema.sql",
        emit=emit,
    )
    files.append({"path": "server/db/schema.sql", "content": schema_sql, "source": "ai"})

    # Step 5b: Express Routes (one per entity)
    for entity in overview_json["data_entities"]:
        route_code = await generate_and_validate(
            prompt=codegen_prompts.route_prompt,
            input_data={"entity": entity, "schema_sql": schema_sql, "sdd_markdown": sdd_markdown},
            validator_tool="validate_js_syntax",
            filename=f"server/routes/{entity.lower()}.js",
            emit=emit,
        )
        files.append({"path": f"server/routes/{entity.lower()}.js", "content": route_code, "source": "ai"})

    # Steps 5c–5f: auth, pages, components, config (same pattern)
    # ...

    return files
```

### 5.6 FastAPI Entry Point (`main.py`)

```python
# ai-service/main.py — Amritansu's file
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from ai_service.routers import ai_router, codegen_router, docs_router
import os

app = FastAPI(title="AppForge AI Service", version="3.0.0")

# Internal-only: only Node.js backend should reach this service
# In production, bind to 127.0.0.1 (not 0.0.0.0) or use a private network
AI_SERVICE_SECRET = os.environ["AI_SERVICE_SECRET"]

@app.middleware("http")
async def verify_internal_secret(request: Request, call_next):
    """Reject any request that doesn't carry the shared internal secret."""
    if not request.url.path.startswith("/health"):
        secret = request.headers.get("X-Internal-Secret")
        if secret != AI_SERVICE_SECRET:
            raise HTTPException(status_code=403, detail="Forbidden")
    return await call_next(request)

app.include_router(ai_router.router)
app.include_router(codegen_router.router)
app.include_router(docs_router.router)

@app.get("/health")
def health():
    return {"status": "ok", "service": "appforge-ai"}
```

### 5.7 Node.js Proxy (how Express calls the Python service)

```javascript
// server/middleware/aiProxy.js — Amritansu's file (still JavaScript)
// Thin proxy: verifies JWT first, then forwards to Python AI service.
import fetch from 'node-fetch';

const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';
const AI_SERVICE_SECRET = process.env.AI_SERVICE_SECRET;

export async function proxyToAI(path, body) {
  const response = await fetch(`${AI_SERVICE_URL}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Internal-Secret': AI_SERVICE_SECRET,
    },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.detail || 'AI service error');
  }
  return response.json();
}

// For SSE streaming: pipe Python SSE response directly to Express SSE response
export async function proxyStreamToAI(path, body, expressRes) {
  const response = await fetch(`${AI_SERVICE_URL}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Internal-Secret': AI_SERVICE_SECRET,
    },
    body: JSON.stringify(body),
  });
  expressRes.setHeader('Content-Type', 'text/event-stream');
  expressRes.setHeader('Cache-Control', 'no-cache');
  expressRes.setHeader('Connection', 'keep-alive');
  response.body.pipe(expressRes);
}
```

### 5.8 LangSmith Tracing Setup (Both Contributors — Python)

Add to `ai-service/main.py` at the top:

```python
# ai-service/main.py — top of file, before anything else
import os
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = os.environ.get("LANGSMITH_API_KEY", "")
os.environ["LANGCHAIN_PROJECT"] = os.environ.get("LANGSMITH_PROJECT", "appforge-dev")
```

After this, every LangChain Python chain invocation is automatically traced in LangSmith. Both contributors should create a free LangSmith account. This is invaluable for debugging malformed AI outputs.

---

## 6. Granular, Modular Implementation Phases

### Parallel Work Protocol
1. **Week 1, Day 1-2:** Both sit together and finalize `API_CONTRACT.md` AND `AI_CHAIN_CONTRACT.md`. Crucially: also agree on the **Python service's internal API** (what endpoints Node.js will call, with exact request/response shapes).
2. Prateeksha builds all frontend against mock API responses AND builds her Python chains against a mock `llm` object.
3. Amritansu builds all Node.js backend AND the Python graph/MCP infrastructure.
4. Integration at Phase milestones.
5. **Branch strategy:** Same as v2.0 — `main` protected, feature branches per phase.

---

### Phase 0: Project Foundation (Weight: 8%)

**Task 0.1: Monorepo Setup & Tooling**
- **Assignee:** Amritansu
- **Target Output:**
  - Root `package.json` with workspaces `["client", "server"]`
  - `client/` — Vite, React, Tailwind, React Query, Zustand, react-markdown, Mermaid, react-router-dom
  - `server/` — Express, better-sqlite3, bcrypt, jsonwebtoken, node-fetch, cors, dotenv, uuid, express-rate-limit
  - **`ai-service/`** — Python project with `requirements.txt`, `main.py`, `.env.example`, folder scaffold
  - Root `dev` script: starts all 3 services concurrently (React :5173, Node :3001, Python uvicorn :8000)
  - `.env.example` at root and in `ai-service/` with all variables from Section 2.4
  - `.gitignore` covering node_modules, .env, data/, server/generated/, ai-service/__pycache__, ai-service/.venv

**Task 0.2: Database Schema & Migration System**
- **Assignee:** Amritansu (Node.js side)
- **Target Output:**
  - `server/db/schema.sql` — all 8 CREATE TABLE statements including `langgraph_checkpoints`
  - `server/db/migrate.js` — idempotent migration runner
  - `server/db/database.js` — singleton DB connection
  - Python AI service also opens the same SQLite file for LangGraph `SqliteSaver` (read-only for app tables; read-write for `langgraph_checkpoints` only)

**Task 0.3: API Contract + AI Chain Contract**
- **Assignee:** Both (synchronous session, 3 hours max)
- **Target Output:**
  - `API_CONTRACT.md` — every REST endpoint (Node.js) with method, path, auth, request body, response
  - `AI_CHAIN_CONTRACT.md` — every Python chain with: input type, output type, which node calls it, which prompt/parser file
  - **`INTERNAL_API_CONTRACT.md`** *(new in v3.0)* — every Node.js→Python internal endpoint with exact JSON shapes. This is the new handshake that replaces v2.0's direct chain-to-node wiring.

**Task 0.4: Folder Structure Scaffold**
- **Assignee:** Amritansu
- **Target Output:** Complete folder tree for `client/`, `server/`, and `ai-service/` as defined in Section 5.2. Empty `__init__.py` in all Python packages. Placeholder Python modules with stub functions so Prateeksha can import without errors.

**Task 0.5: Mock LLM for Development (Python)**
- **Assignee:** Amritansu
- **Target Output:**
  - `ai-service/models/llm_mock.py` — exports a fake `llm` object as a LangChain `RunnableLambda` that returns hardcoded Pydantic/dict responses for each chain type
  - `AI_MOCK_DATA.md` — documents what each mock returns so Prateeksha can build parsers against it

```python
# ai-service/models/llm_mock.py — Amritansu's file
from langchain_core.runnables import RunnableLambda
from langchain_core.messages import AIMessage

MOCK_RESPONSES = {
    "overview": '{"app_name": "TodoMaster", "one_liner": "A simple task manager", ...}',
    "questions": '[{"question_id": "q1", "category": "Users & Roles", ...}]',
    # etc.
}

def _mock_llm(messages) -> AIMessage:
    # Detect chain type from system prompt keyword and return appropriate mock
    system_content = str(messages[0].content) if messages else ""
    if "overview" in system_content.lower():
        return AIMessage(content=MOCK_RESPONSES["overview"])
    if "question" in system_content.lower():
        return AIMessage(content=MOCK_RESPONSES["questions"])
    return AIMessage(content="{}")

llm_mock = RunnableLambda(_mock_llm)
```

---

### Phase 1: Authentication System (Weight: 10%)

> **No change from v2.0.** Auth is entirely in Node.js JavaScript. Python AI service has no auth logic.

**Task 1.1: Auth Backend** — Amritansu (Node.js, same as v2.0)
**Task 1.2: Auth Frontend** — Prateeksha (React, same as v2.0)
**Task 1.3: Auth Middleware + AI Service Secret Injection** — Amritansu
- In addition to JWT middleware: all `/api/ai/*` proxy routes must inject `X-Internal-Secret` header when forwarding to Python

---

### Phase 2: Session, Idea & Overview Chain (Weight: 12%)

**Task 2.1: Session Backend** — Amritansu (Node.js, same as v2.0)

**Task 2.2: LangGraph Graph Infrastructure (Python)**
- **Assignee:** Amritansu
- **Target Output:**
  - `ai-service/graph/appforge_state.py` — full TypedDict state schema from Section 3.5
  - `ai-service/graph/appforge_graph.py` — compiled graph with `SqliteSaver` pointing to `appforge.db`
  - `ai-service/graph/nodes/` — all 5 node files as stubs
  - FastAPI health-check that also verifies graph compiles
  - Integration test: invoke graph with a session_id thread, verify checkpoint row in `langgraph_checkpoints`

**Task 2.3: Overview Chain (Prateeksha's first Python AI task)**
- **Assignee:** Prateeksha
- **Objective:** Build the complete Python Overview chain — `ChatPromptTemplate`, Pydantic model, `PydanticOutputParser`, LCEL pipe.
- **Boundaries:** Export `overview_chain` from `overview_chain.py`. Do not touch `appforge_graph.py`. Amritansu wires it into the graph node.
- **Target Output:**
  - `ai-service/prompts/overview_prompt.py` — `ChatPromptTemplate.from_messages()` with system + human messages
  - `ai-service/parsers/overview_parser.py` — `PydanticOutputParser(pydantic_object=OverviewOutput)`
  - `ai-service/chains/overview_chain.py` — `overview_chain = overview_prompt | llm | overview_parser`
  - Test script `ai-service/tests/test_overview_chain.py` (pytest) — runs chain with mock LLM, asserts all 7 fields present

**Task 2.4: Overview Node, FastAPI Endpoint & Node.js Proxy**
- **Assignee:** Amritansu
- **Boundaries:** Requires Task 2.3 merged first.
- **Target Output:**
  - `ai-service/graph/nodes/overview_node.py` — calls `overview_chain.ainvoke()`, returns partial state dict
  - `ai-service/routers/ai_router.py` — `POST /internal/ai/overview` FastAPI endpoint
  - `server/routes/ai.js` — Node.js proxy: validates JWT + idea (min 20 words), calls `proxyToAI('/internal/ai/overview', ...)`, saves result to SQLite, returns JSON to browser

**Task 2.5: Idea & Overview Frontend** — Prateeksha (React, same as v2.0)

---

### Phase 3: Questions Chain & Answers (Weight: 10%)

**Task 3.1: Questions Chain (Prateeksha's second Python AI task)**
- **Assignee:** Prateeksha
- **Target Output:**
  - `ai-service/prompts/questions_prompt.py` — includes question JSON schema, category list, `{question_count}` variable, no-fences instruction
  - `ai-service/parsers/questions_parser.py` — `JsonOutputParser()` with fallback regex extraction
  - `ai-service/chains/questions_chain.py` — `questions_chain = questions_prompt | llm | JsonOutputParser()`
  - `ai-service/tests/test_questions_chain.py` — asserts correct question count per complexity

**Task 3.2: Questions Backend** — Amritansu (Python node + Node.js proxy + answer routes; same logic as v2.0 but Python node)

**Task 3.3: Questions Frontend** — Prateeksha (React, same as v2.0)

---

### Phase 4: Diagram Chain, MCP Server & Approval UI (Weight: 14%)

**Task 4.1: MCP Server & Client (Python — Amritansu's first major AI task)**
- **Assignee:** Amritansu
- **Target Output:**
  - `ai-service/mcp/tools/validate_mermaid.py` — subprocess to `node -e` with mermaid parse
  - `ai-service/mcp/tools/validate_js.py` — subprocess to `node -e` with acorn
  - `ai-service/mcp/tools/validate_jsx.py` — subprocess to `node -e` with @babel/parser
  - `ai-service/mcp/tools/validate_sql.py` — Python `sqlite3.connect(":memory:")` + `executescript()`
  - `ai-service/mcp/server.py` — `FastMCP` server with all 4 tools registered
  - `ai-service/mcp/mcp_client.py` — in-process async client
  - `ai-service/tests/test_mcp_tools.py` — pytest: valid + invalid inputs for each tool
  - `setup_node_deps.sh` — script to `npm install -g acorn @babel/parser mermaid` so Python subprocess can find them

**Task 4.2: Diagram Chain (Python — Amritansu's second major AI task)**
- **Assignee:** Amritansu (chain + node); Prateeksha writes `diagrams_prompt.py`
- **Target Output:**
  - `ai-service/prompts/diagrams_prompt.py` — **Prateeksha writes this**: ChatPromptTemplate instructing LLM to output JSON with keys `use_case_diagram`, `architecture_diagram`, `er_diagram`; includes concrete Mermaid syntax examples
  - `ai-service/chains/diagram_chain.py` — `generate_diagrams()` with MCP self-correction loop
  - `ai-service/graph/nodes/diagrams_node.py` — calls `generate_diagrams()`
  - FastAPI endpoint `POST /internal/ai/diagrams` + Node.js proxy route
  - Node.js routes for approve/regenerate/get (database operations stay in Node.js)

**Task 4.3: Diagrams Frontend** — Prateeksha (React, same as v2.0)

---

### Phase 5: Documentation Chains & Streaming UI (Weight: 12%)

**Task 5.1: Documentation Chains (Python — Prateeksha's third AI task)**
- **Assignee:** Prateeksha
- **Target Output:**
  - `ai-service/prompts/srs_prompt.py`, `sdd_prompt.py`, `brief_prompt.py` — `ChatPromptTemplate.from_messages()` with large, structured system prompts
  - `ai-service/chains/documentation_chain.py` — `stream_doc()` async generator using `chain.astream()` (full code in Section 5.4)
  - `ai-service/tests/test_docs_chain.py` — streams SRS for sample context, confirms non-empty accumulated text

**Task 5.2: Documentation Backend**
- **Assignee:** Amritansu
- **Target Output:**
  - `ai-service/graph/nodes/docs_node.py` — calls `stream_doc()` for each doc type
  - `ai-service/routers/docs_router.py` — FastAPI SSE endpoints `POST /internal/docs/stream/{doc_type}` using `StreamingResponse`
  - `ai-service/services/doc_generator.py` — `md_to_docx(markdown_text, output_path)` using `python-docx`
  - `server/routes/ai.js` — Node.js SSE proxy routes for SRS/SDD/brief (pipe Python SSE → browser SSE)
  - `server/routes/docs.js` — Node.js file download routes (Python service writes .docx to shared volume; Node.js serves it)

**Task 5.3: Documentation Frontend** — Prateeksha (React, same as v2.0)

---

### Phase 6: Codegen Chain, MCP Validation & Download (Weight: 25%)

**Task 6.1: Codegen Prompts (Python — Prateeksha's fourth AI task)**
- **Assignee:** Prateeksha
- **Target Output:**
  - `ai-service/prompts/codegen_prompts.py` — exports 5 named `ChatPromptTemplate` instances:
    - `schema_prompt` — generates SQL CREATE TABLE statements
    - `route_prompt` — generates Express router JS file for one entity
    - `auth_prompt` — generates auth middleware + auth routes for generated app
    - `page_prompt` — generates one React page component
    - `component_prompt` — generates shared React components
  - Each prompt's system message must end with: "Output only the file contents. No explanation. No markdown fences. No preamble."
  - Test script `ai-service/tests/test_codegen_prompts.py` — runs each prompt, saves raw outputs for joint review

**Task 6.2: Codegen Chain Orchestrator (Python — Amritansu)**
- **Target Output:**
  - `ai-service/chains/codegen_chain.py` — `run_codegen_chain({ state, emit })` (full code in Section 5.5)
  - `ai-service/graph/nodes/codegen_node.py`
  - `ai-service/routers/codegen_router.py` — FastAPI SSE `POST /internal/codegen/start`

**Task 6.3: Code Generation Templates** — Amritansu (same as v2.0, template files in `ai-service/templates/`)

**Task 6.4: Codegen Backend Endpoints**
- **Assignee:** Amritansu
- **Target Output:**
  - `server/routes/codegen.js` — Node.js proxy: SSE stream from Python to browser; final zip download route
  - `ai-service/services/zip_builder.py` — uses Python `zipfile` stdlib to assemble generated app zip
  - `GET /api/codegen/download/:sessionId` — Node.js reads zip from shared storage, streams to browser

**Task 6.5: Code Generation Frontend** — Prateeksha (React, same as v2.0)

---

### Phase 7: History, Polish & Error Handling (Weight: 9%)

**Task 7.1: History Page** — Prateeksha (React, same as v2.0)

**Task 7.2: Global Error Handling & Rate Limiting**
- **Assignee:** Amritansu
- **Node.js side:** `express-rate-limit`, global error handler, AI service connection error handling
- **Python side:** FastAPI exception handlers for LangChain errors, normalize to `{detail: str}` JSON

**Task 7.3: Frontend Toast & Global Error States** — Prateeksha (React, same as v2.0)

**Task 7.4: LangSmith Integration Review (Joint)**
- Open LangSmith, run full pipeline, review every Python chain's trace
- Improve at least 1 prompt each based on trace review
- `PROMPT_ITERATION_LOG.md` — evidence of real AI engineering

---

### Phase 8: Testing & Pre-Submission (Weight: 5%)

**Task 8.1: Backend Unit Tests** — Amritansu (Node.js Jest: auth, session, answer, diagram routes)

**Task 8.2: Python AI Chain Unit Tests (pytest)**
- **Assignee:** Both (joint session)
- **Target Output:** `ai-service/tests/` — one pytest file per chain:
  - `test_overview_chain.py` (Prateeksha): mock LLM → valid Pydantic object; fenced JSON → parser strips and succeeds
  - `test_questions_chain.py` (Prateeksha): correct question count per complexity
  - `test_diagram_chain.py` (Amritansu): valid Mermaid passes first try; invalid then valid succeeds on retry; 3× invalid raises
  - `test_codegen_chain.py` (Amritansu): MCP tool called per file; retries on validation failure
  - `test_mcp_tools.py` (Amritansu): each tool with valid AND invalid inputs

**Task 8.3: Frontend Component Tests** — Prateeksha (Vitest + React Testing Library, same as v2.0)

**Task 8.4: End-to-End Smoke Test** — Both (same 3 test ideas as v2.0)

---

## 7. Verification & Testing Suite

### Phase 0 Verification
| Task | Test | Pass Criteria |
|------|------|---------------|
| 0.1 | `npm run dev` from root | All 3 servers start: React :5173, Node :3001, Python :8000 |
| 0.1 | `GET http://localhost:8000/health` | Returns `{"status": "ok", "service": "appforge-ai"}` |
| 0.2 | `npm run db:migrate` then `.tables` | Lists all 8 tables |
| 0.5 | `pytest ai-service/tests/test_mock_llm.py` | Mock LLM returns deterministic response for each chain type |

### Phase 1 Verification
*(Same as v2.0 — Node.js auth unchanged)*

### Phase 2 Verification
| Task | Test | Pass Criteria |
|------|------|---------------|
| 2.2 | `await compiled_graph.ainvoke(stub_state, config={...})` in pytest | Checkpoint row in `langgraph_checkpoints` |
| 2.3 | `pytest ai-service/tests/test_overview_chain.py` | Returns OverviewOutput Pydantic model with all 7 fields |
| 2.3 | Mock LLM returns fenced JSON | `PydanticOutputParser` still returns correct object |
| 2.4 | `POST /api/ai/overview` (via Node.js) | Returns overview JSON; saved to SQLite |

### Phase 4 Verification
| Task | Test | Pass Criteria |
|------|------|---------------|
| 4.1 | `pytest ai-service/tests/test_mcp_tools.py::test_validate_mermaid_valid` | Returns `{"valid": true}` |
| 4.1 | `pytest ai-service/tests/test_mcp_tools.py::test_validate_mermaid_invalid` | Returns `{"valid": false, "error": "..."}` |
| 4.1 | `pytest ai-service/tests/test_mcp_tools.py::test_validate_sql_valid` | Returns `{"valid": true}` |
| 4.1 | `pytest ai-service/tests/test_mcp_tools.py::test_validate_sql_error` | Returns `{"valid": false, "error": "..."}` |
| 4.2 | `generate_diagrams()` with real LLM | Returns 3 valid Mermaid strings |

### Phase 6 Verification
| Task | Test | Pass Criteria |
|------|------|---------------|
| 6.2 | `run_codegen_chain()` for "todo app" | SSE streams 6+ step events; all files reach `validated` |
| 6.4 | `GET /api/codegen/download/:sessionId` | Zip downloads; unzip reveals `client/` and `server/` |
| 6.4 | Generated schema.sql | Python `sqlite3.connect(":memory:").executescript(sql)` — no error |
| 6.4 | Generated route JS | Node.js `acorn.parse()` — no error |
| 6.4 | Generated JSX | `@babel/parser.parse()` — no error |

---

## 8. AI Learning Outcomes by Contributor

### What Prateeksha will have genuinely built and learned (Python):

| Skill | Language | Where |
|-------|----------|-------|
| `ChatPromptTemplate.from_messages()` | Python | All 6+ prompt files |
| `PydanticOutputParser` with Pydantic v2 BaseModel | Python | `overview_parser.py` |
| `JsonOutputParser` | Python | `questions_parser.py` |
| LCEL pipe syntax: `prompt \| model \| parser` | Python | All chain files |
| `StrOutputParser` + async streaming with `astream()` | Python | `documentation_chain.py` |
| Prompt engineering for structured JSON output | Python | All prompts |
| Prompt engineering for code generation | Python | `codegen_prompts.py` |
| LangSmith trace reading | Python | Phase 7.4 joint session |

### What Amritansu will have genuinely built and learned (Python + JavaScript):

| Skill | Language | Where |
|-------|----------|-------|
| `ChatGroq` + `ChatGoogleGenerativeAI` Python models | Python | `llm.py` |
| `.with_fallbacks()` Python pattern | Python | `llm.py` |
| `StateGraph` with Python `TypedDict` state | Python | `appforge_graph.py`, `appforge_state.py` |
| LangGraph async nodes | Python | All 5 node files |
| `SqliteSaver` checkpointing (Python) | Python | `appforge_graph.py` |
| MCP server with Python `FastMCP` | Python | `mcp/server.py` |
| MCP tool definition with Pydantic/type hints | Python | All 4 tool files |
| Self-correction loop pattern | Python | `diagram_chain.py`, `codegen_chain.py` |
| FastAPI `StreamingResponse` for SSE | Python | `docs_router.py`, `codegen_router.py` |
| Node.js→Python proxy integration | JavaScript | `server/middleware/aiProxy.js` |
| LangSmith trace reading | Python | Phase 7.4 joint session |

---

## Appendix A: Branch & Merge Strategy

*(Same branch names as v2.0 — just note that AI branches now contain Python code.)*

```
main (protected — requires PR review from other person)
├── feat/phase0-foundation              → Amritansu (includes ai-service/ scaffold)
├── feat/phase1-auth-backend            → Amritansu (Node.js)
├── feat/phase1-auth-frontend           → Prateeksha (React)
├── feat/phase2-session-backend         → Amritansu (Node.js)
├── feat/phase2-graph-infrastructure    → Amritansu (Python LangGraph)
├── feat/ai-overview-chain              → Prateeksha (Python)
├── feat/phase2-idea-frontend           → Prateeksha (React)
├── feat/ai-questions-chain             → Prateeksha (Python)
├── feat/phase3-questions-backend       → Amritansu (Python node + Node.js proxy)
├── feat/phase3-questions-frontend      → Prateeksha (React)
├── feat/ai-mcp-server                  → Amritansu (Python)
├── feat/ai-diagram-chain               → Amritansu (Python)
├── feat/ai-diagrams-prompt             → Prateeksha (Python prompt file only)
├── feat/phase4-diagrams-frontend       → Prateeksha (React)
├── feat/ai-docs-chains                 → Prateeksha (Python)
├── feat/phase5-docs-backend            → Amritansu (Python FastAPI + Node.js proxy)
├── feat/phase5-docs-frontend           → Prateeksha (React)
├── feat/ai-codegen-prompts             → Prateeksha (Python prompt files only)
├── feat/ai-codegen-chain               → Amritansu (Python)
├── feat/phase6-codegen-backend         → Amritansu (Python FastAPI + Node.js proxy)
├── feat/phase6-codegen-frontend        → Prateeksha (React)
└── feat/phase7-polish                  → Both
```

---

## Appendix B: AI_CHAIN_CONTRACT.md Template (Python Edition)

```markdown
# AI Chain Contract — Python

## Chain: overview_chain
- **File:** ai-service/chains/overview_chain.py
- **Owner:** Prateeksha
- **Language:** Python
- **Input:** { "idea_text": str, "format_instructions": str }
- **Output:** OverviewOutput (Pydantic model — see overview_parser.py)
- **Called by:** overview_node.py (Amritansu)
- **Prompt file:** ai-service/prompts/overview_prompt.py (Prateeksha)
- **Parser file:** ai-service/parsers/overview_parser.py (Prateeksha)
- **FastAPI endpoint:** POST /internal/ai/overview

## Chain: questions_chain
- **File:** ai-service/chains/questions_chain.py
- **Owner:** Prateeksha
- **Language:** Python
- **Input:** { "overview_json": str, "question_count": int }
- **Output:** list[dict] — each dict: { question_id, category, question, type, options? }
- **Called by:** questions_node.py (Amritansu)
- **FastAPI endpoint:** POST /internal/ai/questions

## Function: stream_doc
- **File:** ai-service/chains/documentation_chain.py
- **Owner:** Prateeksha
- **Language:** Python (async generator)
- **Input:** { doc_type: "srs"|"sdd"|"brief", session_context: dict, on_token: Callable, on_complete: Callable }
- **Output:** None (side effects via callbacks)
- **FastAPI endpoint:** POST /internal/docs/stream/{doc_type} (StreamingResponse)

## Function: generate_diagrams
- **File:** ai-service/chains/diagram_chain.py
- **Owner:** Amritansu
- **Language:** Python
- **Input:** overview_json: dict, answers: list
- **Output:** { use_case_diagram: str, architecture_diagram: str, er_diagram: str }
- **MCP tools used:** validate_mermaid × 3
- **FastAPI endpoint:** POST /internal/ai/diagrams

## Function: run_codegen_chain
- **File:** ai-service/chains/codegen_chain.py
- **Owner:** Amritansu
- **Language:** Python
- **Input:** state: AppForgeState, emit: Callable[[dict], None]
- **Output:** list[{ path: str, content: str, source: str }]
- **MCP tools used:** validate_sql_schema, validate_js_syntax, validate_jsx_syntax
- **FastAPI endpoint:** POST /internal/codegen/start (StreamingResponse SSE)
```

---

## Appendix C: Python Package Reference

| Package | Purpose | Docs |
|---------|---------|------|
| `langchain` | Core LangChain Python (runnables, parsers) | python.langchain.com |
| `langchain-core` | Primitives — prompts, runnables, output parsers | python.langchain.com |
| `langchain-groq` | `ChatGroq` model | python.langchain.com/docs/integrations/chat/groq |
| `langchain-google-genai` | `ChatGoogleGenerativeAI` model | python.langchain.com |
| `langgraph` | `StateGraph`, nodes, edges | langchain-ai.github.io/langgraph |
| `langgraph-checkpoint-sqlite` | `SqliteSaver` checkpointer | langchain-ai.github.io/langgraph |
| `mcp` | MCP server + `FastMCP` tool registration | modelcontextprotocol.io/python |
| `pydantic` | Schema validation — replaces Zod | docs.pydantic.dev |
| `fastapi` | Python AI service web framework | fastapi.tiangolo.com |
| `uvicorn` | ASGI server for FastAPI | uvicorn.org |
| `python-docx` | `.docx` generation — replaces npm `docx` | python-docx.readthedocs.io |
| `langsmith` | Tracing (optional, dev only) | smith.langchain.com |

## Appendix D: Node.js Package Reference (unchanged)

| Package | Purpose |
|---------|---------|
| `express` | Node.js REST API |
| `better-sqlite3` | Synchronous SQLite driver |
| `bcrypt` | Password hashing |
| `jsonwebtoken` | JWT auth |
| `node-fetch` | HTTP client for Node→Python proxy calls |
| `express-rate-limit` | Rate limiting |
| `cors`, `dotenv`, `uuid` | Utilities |

---

*End of Blueprint v3.0*