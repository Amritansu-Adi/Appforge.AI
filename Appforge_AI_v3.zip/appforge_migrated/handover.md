# EXECUTION HANDOVER STATE: Phase 0 — Python Migration (v2.0 JS → v3.0 Python AI Layer)

## 1. Execution Summary
- **Completed:** Migrated Phase 0 scaffold from JS-based monolith (AI in `server/ai/`) to v3.0 tri-service architecture: React `:5173` + Node.js `:3001` + Python FastAPI `:8000`. All JS LangChain/LangGraph/MCP code removed from `server/`. New `ai-service/` Python package created with full folder scaffold, `__init__.py` files, `requirements.txt`, `main.py`, Python equivalents of all stubs (models, prompts, parsers, chains, graph, nodes, MCP tools/server/client, routers, services, tests).
- **Current Target State:** Phase 0 complete. Next agent picks up **Phase 1 — Task 1.1: Auth Backend** (`server/routes/auth.js` + `server/middleware/authenticate.js`). The Python AI service has a working `/health` endpoint and can be started with `uvicorn main:app --reload --port 8000` from `ai-service/`.

---

## 2. Infrastructure & System Provisions

### NPM Packages — server workspace (`server/package.json`) — CLEANED
```
express@^4.19.2, better-sqlite3@^9.6.0, bcrypt@^5.1.1, jsonwebtoken@^9.0.2,
cors@^2.8.5, dotenv@^16.4.5, uuid@^10.0.0,
node-fetch@^3.3.2, express-rate-limit@^7.3.1
```
**REMOVED** from server: all `@langchain/*`, `@modelcontextprotocol/sdk`, `langgraph*`, `zod`, `acorn`, `@babel/parser`, `docx`, `archiver`, `mermaid`

### NPM Packages — client workspace (UNCHANGED)
```
react@^18.3.1, react-dom, react-router-dom@^6.23.1,
@tanstack/react-query@^5.45.0, zustand@^4.5.2,
react-markdown@^9.0.1, mermaid@^10.9.0, axios@^1.7.7
```

### Python packages — `ai-service/requirements.txt`
```
fastapi>=0.111.0, uvicorn[standard]>=0.29.0,
langchain>=0.3.0, langchain-core>=0.3.0,
langchain-groq>=0.2.0, langchain-google-genai>=2.0.0,
langgraph>=0.2.0, langgraph-checkpoint-sqlite>=2.0.0,
langsmith>=0.1.0, pydantic>=2.7.0, python-docx>=1.1.0,
mcp>=1.0.0, httpx>=0.27.0, python-dotenv>=1.0.0,
pytest>=8.0.0, pytest-asyncio>=0.23.0
```

### New Environment Variables (root `.env.example` + `ai-service/.env.example`)
```
AI_SERVICE_SECRET=<openssl rand -base64 32>   # shared Node.js ↔ Python secret
AI_SERVICE_URL=http://localhost:8000           # used by Node.js proxy
AI_PORT=8000                                   # Python service port
```
Existing vars retained: `GROQ_API_KEY`, `GEMINI_API_KEY`, `JWT_SECRET`, `LANGSMITH_API_KEY`, `LANGSMITH_PROJECT`, `NODE_ENV`, `PORT`, `DB_PATH`

### Root `package.json` dev scripts
```json
"dev": "concurrently ... \"npm run dev --workspace=client\" \"npm run dev --workspace=server\" \"cd ai-service && uvicorn main:app --reload --port 8000\""
"setup": "npm install && pip install -r ai-service/requirements.txt && npm run db:migrate"
```

### File System — what changed
```
DELETED:  server/ai/           (all JS LangChain models/prompts/parsers/chains/graph/mcp)
DELETED:  server/chains/       (JS chain files)
DELETED:  server/graph/        (JS LangGraph files)
DELETED:  server/mcp/          (JS MCP server/client/tools)
DELETED:  server/parsers/      (JS parsers)

ADDED:    ai-service/           Python microservice root
ADDED:    ai-service/main.py    FastAPI app + X-Internal-Secret middleware + /health
ADDED:    ai-service/models/llm.py        ChatGroq + ChatGemini .with_fallbacks()
ADDED:    ai-service/models/llm_mock.py   RunnableLambda mock for dev
ADDED:    ai-service/graph/appforge_state.py   TypedDict AppForgeState schema
ADDED:    ai-service/graph/appforge_graph.py   LangGraph StateGraph + SqliteSaver
ADDED:    ai-service/graph/nodes/*.py      5 node stubs
ADDED:    ai-service/prompts/*.py          7 prompt stubs (ChatPromptTemplate)
ADDED:    ai-service/parsers/*.py          4 parser stubs
ADDED:    ai-service/chains/*.py           5 chain stubs
ADDED:    ai-service/mcp/tools/*.py        4 validation tools (SQL is functional; JS/Mermaid need node)
ADDED:    ai-service/mcp/server.py         FastMCP server
ADDED:    ai-service/mcp/mcp_client.py     In-process async McpClient
ADDED:    ai-service/routers/*.py          3 router stubs
ADDED:    ai-service/services/*.py         2 service stubs
ADDED:    ai-service/tests/*.py            5 test files (SQL tests functional; others skipped)
ADDED:    ai-service/requirements.txt
ADDED:    ai-service/.env.example
ADDED:    ai-service/setup_node_deps.sh    npm install -g acorn @babel/parser
MODIFIED: server/package.json              Removed all JS AI deps; added node-fetch
MODIFIED: server/index.js                  Updated health endpoint; AI proxy route comments
ADDED:    server/middleware/aiProxy.js     proxyToAI() + proxyStreamToAI()
MODIFIED: .env.example                     Added AI_SERVICE_SECRET, AI_SERVICE_URL, AI_PORT
MODIFIED: .gitignore                       Added Python artifacts (__pycache__, .venv, .pytest_cache)
MODIFIED: package.json (root)              Added concurrently, 3-service dev script, setup script
```

---

## 3. Integration Contracts & Data Types

### Python AppForgeState (TypedDict)
```python
# ai-service/graph/appforge_state.py
AppForgeState = {
    "session_id": str,
    "user_id": str,
    "current_phase": "overview"|"questions"|"diagrams"|"docs"|"codegen"|"complete",
    "idea_text": str,
    "overview_json": Optional[OverviewOutput],      # OverviewOutput TypedDict
    "questions": list[Question],
    "answers": list[Answer],
    "complexity": Optional["simple"|"standard"|"complex"],
    "diagrams": Optional[DiagramSet],               # DiagramSet TypedDict
    "diagram_errors": list[str],
    "srs_markdown": str,
    "sdd_markdown": str,
    "brief_markdown": str,
    "generated_files": list[GeneratedFile],         # GeneratedFile TypedDict
    "zip_path": Optional[str],
    "retry_count": int,
    "last_error": Optional[str],
}
```

### Node.js → Python proxy (aiProxy.js)
```javascript
// Non-streaming:
import { proxyToAI } from "./middleware/aiProxy.js";
const result = await proxyToAI("/internal/ai/overview", { session_id, idea_text });
// result: JSON from Python

// Streaming SSE:
import { proxyStreamToAI } from "./middleware/aiProxy.js";
await proxyStreamToAI("/internal/codegen/start", body, res);
// Pipes Python SSE directly to Express res
```

### Python internal API shapes (FastAPI — Amritansu wires in Phase 2.4+)
```json
POST /internal/ai/overview
  Request:  { "session_id": "uuid", "user_id": "uuid", "idea_text": "string" }
  Response: { "app_name": "str", "one_liner": "str", "target_users": [], "core_features": [], "complexity": "simple|standard|complex", "tech_notes": "str", "data_entities": [] }

POST /internal/ai/questions
  Request:  { "session_id": "uuid", "overview_json": {}, "question_count": 6|8|10 }
  Response: [{ "question_id": "q1", "category": "str", "question": "str", "type": "text|choice", "options": [] }]

POST /internal/ai/diagrams
  Request:  { "session_id": "uuid", "overview_json": {}, "answers": [] }
  Response: { "use_case_diagram": "mermaid str", "architecture_diagram": "mermaid str", "er_diagram": "mermaid str" }

POST /internal/docs/stream/{doc_type}   → StreamingResponse SSE
  Request:  { "session_id": "uuid", "session_context": {} }
  Stream:   data: <token>\n\n  ...  data: DONE\n\n

POST /internal/codegen/start            → StreamingResponse SSE
  Request:  { "session_id": "uuid", "overview_json": {}, "sdd_markdown": "str" }
  Stream:   data: {"step": "schema.sql", "status": "generating|validating|validated|failed"}\n\n
```

### LLM abstraction (Python)
```python
from ai_service.models.llm import llm
# llm = ChatGroq.with_fallbacks([ChatGoogleGenerativeAI])
# Use in LCEL: chain = prompt | llm | parser
# Async: result = await chain.ainvoke({...})
# Streaming: async for chunk in chain.astream({...}): ...
```

### MCP client (Python)
```python
from ai_service.mcp.mcp_client import mcp_client
result = await mcp_client.call_tool("validate_sql_schema", {"sql": "CREATE TABLE..."})
# result: { "valid": True }
result = await mcp_client.call_tool("validate_mermaid", {"src": "graph TD...", "type": "er"})
# result: { "valid": True|False, "error"?: "str" }
```

### DB singleton (Node.js — UNCHANGED)
```javascript
import db from "../db/database.js";
db.prepare("SELECT * FROM sessions WHERE id = ?").get(sessionId);
```

---

## 4. What the Next Agent Must Build — Phase 1, Task 1.1

**File:** `server/routes/auth.js`
- `POST /api/auth/register` — email + min 8 char password → bcrypt 10 rounds → uuid v4 id → JWT 24h
- `POST /api/auth/login` — credential check → JWT + `{id, email}`
- `POST /api/auth/logout` — stateless, 200 OK
- `GET /api/auth/me` — requires authenticate middleware → returns user row

**File:** `server/middleware/authenticate.js`
- Reads `Authorization: Bearer <token>` → verifies with `JWT_SECRET` → attaches `req.user = { id, email }`
- Returns `401 { error: "..." }` on failure

**Wire into:** `server/index.js` — uncomment `app.use("/api/auth", authRouter)`

**Key output shape:**
```json
{ "token": "JWT string", "user": { "id": "uuid-v4", "email": "lowercase string" } }
```

---

## 5. Known Stubs / Deferred Work

| File | Owner | Status | Phase |
|------|-------|--------|-------|
| `ai-service/prompts/overview_prompt.py` | Prateeksha | Stub (minimal impl) | 2.3 |
| `ai-service/parsers/overview_parser.py` | Prateeksha | Stub (Pydantic model defined) | 2.3 |
| `ai-service/chains/overview_chain.py` | Prateeksha | Stub (chain=None) | 2.3 |
| `ai-service/graph/nodes/overview_node.py` | Amritansu | Stub | 2.4 |
| `ai-service/prompts/questions_prompt.py` | Prateeksha | Stub | 3.1 |
| `ai-service/chains/questions_chain.py` | Prateeksha | Stub | 3.1 |
| `ai-service/graph/nodes/questions_node.py` | Amritansu | Stub | 3.2 |
| `ai-service/prompts/diagrams_prompt.py` | Prateeksha | Stub | 4.2 |
| `ai-service/chains/diagram_chain.py` | Amritansu | Stub | 4.2 |
| `ai-service/graph/nodes/diagrams_node.py` | Amritansu | Stub | 4.2 |
| `ai-service/prompts/srs/sdd/brief_prompt.py` | Prateeksha | Stub | 5.1 |
| `ai-service/chains/documentation_chain.py` | Prateeksha | Stub | 5.1 |
| `ai-service/graph/nodes/docs_node.py` | Amritansu | Stub | 5.2 |
| `ai-service/routers/ai_router.py` | Amritansu | Stub | 2.4-4.2 |
| `ai-service/routers/docs_router.py` | Amritansu | Stub | 5.2 |
| `ai-service/prompts/codegen_prompts.py` | Prateeksha | Stub | 6.1 |
| `ai-service/chains/codegen_chain.py` | Amritansu | Stub | 6.2 |
| `ai-service/graph/nodes/codegen_node.py` | Amritansu | Stub | 6.2 |
| `ai-service/routers/codegen_router.py` | Amritansu | Stub | 6.2 |
| `ai-service/services/doc_generator.py` | Amritansu | Stub | 5.2 |
| `ai-service/services/zip_builder.py` | Amritansu | Stub | 6.4 |
| `server/routes/auth.js` | Amritansu | NOT CREATED | **Phase 1.1 — NEXT** |
| `server/middleware/authenticate.js` | Amritansu | NOT CREATED | **Phase 1.1 — NEXT** |
| All `client/src/pages/*` | Prateeksha | Placeholder | Phase 1+ |

## 6. Functional / Tested Now
- `validate_sql_schema()` — fully functional Python sqlite3 validation (no deps needed)
- `validate_mermaid()` — basic structural check (keyword-based, no Node.js required)
- `mcp_client.call_tool()` — async dispatch works for SQL and Mermaid
- `main.py /health` endpoint — returns `{"status": "ok"}` with correct secret
- `server/db/` — schema.sql, migrate.js, database.js all intact from Phase 0
- `server/middleware/aiProxy.js` — proxy helpers ready (not wired into routes yet — Phase 1.3)
